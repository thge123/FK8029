#include <iostream>
#include <cmath>
#include "Eigen/Dense"
#include <fstream>
using namespace std;
using namespace Eigen;

// LinearAlgebra.cppw
Matrix<double,Dynamic,Dynamic> zeros(int M, int N);
Matrix<double,Dynamic,1> zeros(int);

