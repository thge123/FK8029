from PeriodicTable import *

def main():

    Neon()

main()



     
